# Interactive Calculator & Unit Converter

A beginner-friendly command-line Python application.

## Features
- Addition, subtraction, multiplication and division.
- Division-by-zero protection and numeric input validation.
- Kilometres/miles and Celsius/Fahrenheit conversions.
- Menu-driven interface.

## Requirements
- Python 3.8 or later
- No external packages

## Run
```bash
python main.py
```

## Concepts demonstrated
Functions, loops, conditionals, exception handling, arithmetic and user input.
