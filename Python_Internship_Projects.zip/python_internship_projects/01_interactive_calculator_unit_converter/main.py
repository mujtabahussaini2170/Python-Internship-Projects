"""Interactive calculator and unit converter."""
def calculator():
    print("\nCalculator: enter q to return")
    while True:
        raw = input("First number: ").strip()
        if raw.lower() == "q":
            return
        try:
            a = float(raw)
            op = input("Operation (+, -, *, /): ").strip()
            b = float(input("Second number: "))
            if op == "+": result = a + b
            elif op == "-": result = a - b
            elif op == "*": result = a * b
            elif op == "/":
                if b == 0:
                    print("Cannot divide by zero.")
                    continue
                result = a / b
            else:
                print("Unsupported operation.")
                continue
            print(f"Result: {result:g}")
        except ValueError:
            print("Please enter valid numbers.")

def unit_converter():
    print("\nUnit converter")
    print("1. Kilometres to miles")
    print("2. Miles to kilometres")
    print("3. Celsius to Fahrenheit")
    print("4. Fahrenheit to Celsius")
    choice = input("Choose 1-4: ").strip()
    try:
        value = float(input("Value: "))
        conversions = {
            "1": (value * 0.621371, "miles"),
            "2": (value / 0.621371, "kilometres"),
            "3": (value * 9 / 5 + 32, "°F"),
            "4": ((value - 32) * 5 / 9, "°C"),
        }
        if choice not in conversions:
            print("Invalid choice.")
        else:
            result, unit = conversions[choice]
            print(f"Converted value: {result:.2f} {unit}")
    except ValueError:
        print("Please enter a valid number.")

def main():
    while True:
        print("\n=== Calculator & Unit Converter ===")
        print("1. Calculator\n2. Unit converter\n3. Exit")
        choice = input("Select an option: ").strip()
        if choice == "1": calculator()
        elif choice == "2": unit_converter()
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
