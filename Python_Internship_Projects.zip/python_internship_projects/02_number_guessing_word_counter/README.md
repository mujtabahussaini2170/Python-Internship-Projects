# Number Guessing Game & Word Counter

Two small command-line tools in one menu-driven application.

## Features
- Random number from 1 to 100, with high/low hints and attempt count.
- Counts words, characters and lines from typed text or a UTF-8 text file.
- Validates input and handles file errors.

## Requirements
Python 3.8 or later. No external packages.

## Run
```bash
python main.py
```

## Concepts demonstrated
`random`, file handling, strings, functions, loops and exception handling.
