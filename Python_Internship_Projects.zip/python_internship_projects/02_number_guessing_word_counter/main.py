"""Number guessing game and text/file word counter."""
import random
from pathlib import Path

def number_guessing_game():
    secret = random.randint(1, 100)
    attempts = 0
    print("\nGuess the number between 1 and 100. Enter q to quit.")
    while True:
        raw = input("Your guess: ").strip()
        if raw.lower() == "q":
            print(f"The number was {secret}.")
            return
        try:
            guess = int(raw)
            if not 1 <= guess <= 100:
                print("Enter a number from 1 to 100.")
                continue
            attempts += 1
            if guess < secret:
                print("Too low!")
            elif guess > secret:
                print("Too high!")
            else:
                print(f"Correct! You won in {attempts} attempt(s).")
                return
        except ValueError:
            print("Please enter a whole number.")

def count_words(text):
    words = text.split()
    return len(words), len(text), len(text.splitlines())

def word_counter():
    print("\n1. Type/paste text\n2. Count words in a text file")
    choice = input("Choose 1 or 2: ").strip()
    if choice == "1":
        print("Enter text. Submit an empty line to finish:")
        lines = []
        while True:
            line = input()
            if not line:
                break
            lines.append(line)
        text = "\n".join(lines)
    elif choice == "2":
        filename = input("Text file path: ").strip()
        try:
            text = Path(filename).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            print(f"Could not read file: {exc}")
            return
    else:
        print("Invalid choice.")
        return
    words, characters, lines = count_words(text)
    print(f"Words: {words}\nCharacters: {characters}\nLines: {lines}")

def main():
    while True:
        print("\n=== Number Game & Word Counter ===")
        print("1. Number guessing game\n2. Word counter\n3. Exit")
        choice = input("Select an option: ").strip()
        if choice == "1": number_guessing_game()
        elif choice == "2": word_counter()
        elif choice == "3": break
        else: print("Choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
