# Personal Expense Tracker with CSV

A command-line expense tracker that stores records persistently in `expenses.csv`.

## Features
- Add expenses with date, category, description and amount.
- View all entries and calculate total spending.
- Summarize spending by category.
- CSV storage can be opened in Excel or Google Sheets.

## Requirements
Python 3.8 or later. No external packages.

## Run
```bash
python main.py
```
The CSV file is created automatically beside `main.py` when the first expense is saved.

## Concepts demonstrated
CSV read/write, lists, dictionaries, functions, validation and aggregation.
