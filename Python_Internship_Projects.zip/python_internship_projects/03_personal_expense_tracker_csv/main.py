"""Personal expense tracker with persistent CSV storage."""
import csv
from datetime import date, datetime
from pathlib import Path

DATA_FILE = Path(__file__).with_name("expenses.csv")
FIELDS = ["date", "category", "description", "amount"]

def load_expenses():
    if not DATA_FILE.exists():
        return []
    with DATA_FILE.open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))

def save_expenses(expenses):
    with DATA_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(expenses)

def add_expense():
    category = input("Category (food/travel/bills/etc.): ").strip()
    description = input("Description: ").strip()
    try:
        amount = float(input("Amount: ₹"))
        if amount <= 0:
            raise ValueError
    except ValueError:
        print("Amount must be a positive number.")
        return
    expenses = load_expenses()
    expenses.append({
        "date": date.today().isoformat(),
        "category": category or "Other",
        "description": description,
        "amount": f"{amount:.2f}",
    })
    save_expenses(expenses)
    print("Expense saved.")

def show_expenses():
    expenses = load_expenses()
    if not expenses:
        print("No expenses recorded yet.")
        return
    print("\nDate         Category       Description                 Amount")
    print("-" * 70)
    for item in expenses:
        print(f"{item['date']:<12} {item['category']:<14} {item['description']:<26} ₹{float(item['amount']):>8.2f}")
    print("-" * 70)
    print(f"Total: ₹{sum(float(x['amount']) for x in expenses):.2f}")

def category_summary():
    totals = {}
    for item in load_expenses():
        totals[item["category"]] = totals.get(item["category"], 0) + float(item["amount"])
    if not totals:
        print("No expenses to summarize.")
        return
    print("\nCategory summary")
    for category, total in sorted(totals.items()):
        print(f"{category:<20} ₹{total:.2f}")

def main():
    while True:
        print("\n=== Personal Expense Tracker ===")
        print("1. Add expense\n2. View all expenses\n3. Category summary\n4. Exit")
        choice = input("Select an option: ").strip()
        if choice == "1": add_expense()
        elif choice == "2": show_expenses()
        elif choice == "3": category_summary()
        elif choice == "4": break
        else: print("Choose 1, 2, 3, or 4.")

if __name__ == "__main__":
    main()
