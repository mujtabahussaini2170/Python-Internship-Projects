# Web Scraper for Headlines & Quotes

An educational scraper that collects quotes, authors and tags from the public demo website `https://quotes.toscrape.com/` and saves them to CSV.

## Requirements
- Python 3.8+
- Internet connection
- Packages in `requirements.txt`

## Setup and run
```bash
python -m pip install -r requirements.txt
python main.py
```

## Output
Creates `quotes.csv` in the project folder and prints a small preview.

## Responsible-use notes
This project targets a public scraping practice site, uses a descriptive user agent, has a timeout, and pauses between pages. Always check a website's terms and `robots.txt` before scraping other sites; do not use this example to bypass access controls.

## Concepts demonstrated
HTTP requests, HTML parsing with BeautifulSoup, pagination, CSV export and error handling.
