"""A polite scraper for the public Quotes to Scrape demo website."""
import csv
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

START_URL = "https://quotes.toscrape.com/"
HEADERS = {"User-Agent": "EducationalPythonScraper/1.0 (student project)"}

def scrape_quotes(max_pages=3):
    session = requests.Session()
    session.headers.update(HEADERS)
    url = START_URL
    results = []
    for _ in range(max_pages):
        response = session.get(url, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        for quote in soup.select("div.quote"):
            text = quote.select_one("span.text")
            author = quote.select_one("small.author")
            tags = [tag.get_text(strip=True) for tag in quote.select("a.tag")]
            results.append({
                "quote": text.get_text(strip=True) if text else "",
                "author": author.get_text(strip=True) if author else "",
                "tags": ", ".join(tags),
            })
        next_link = soup.select_one("li.next a")
        if not next_link:
            break
        url = urljoin(url, next_link["href"])
        time.sleep(1)  # keep requests gentle
    return results

def main():
    try:
        rows = scrape_quotes()
        if not rows:
            print("No quotes found.")
            return
        output = "quotes.csv"
        with open(output, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=["quote", "author", "tags"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved {len(rows)} quotes to {output}")
        for row in rows[:5]:
            print(f"\n{row['quote']}\n— {row['author']}")
    except requests.RequestException as exc:
        print(f"Network/request error: {exc}")
    except (KeyError, OSError) as exc:
        print(f"Could not process or save results: {exc}")

if __name__ == "__main__":
    main()
