# Weather App with Live OpenWeatherMap API

A command-line application that fetches current weather for a city.

## Features
- Current condition, temperature, feels-like temperature, humidity and wind speed.
- Metric units (°C and m/s).
- Handles missing/invalid API keys, unknown cities and network errors.

## Requirements
- Python 3.8+
- OpenWeatherMap API key
- `requests` package

## Setup
1. Create an account at https://openweathermap.org/api and obtain an API key.
2. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Set the environment variable.

   Windows PowerShell:
   ```powershell
   $env:OPENWEATHER_API_KEY="YOUR_API_KEY"
   python main.py
   ```

   macOS/Linux:
   ```bash
   export OPENWEATHER_API_KEY="YOUR_API_KEY"
   python main.py
   ```

Never upload your API key to GitHub. The app reads it from an environment variable.

## Concepts demonstrated
REST API calls, JSON, environment variables, exception handling and user input.
