"""Command-line current weather lookup using OpenWeatherMap."""
import os
import requests

API_URL = "https://api.openweathermap.org/data/2.5/weather"

def get_weather(city, api_key):
    response = requests.get(
        API_URL,
        params={"q": city, "appid": api_key, "units": "metric"},
        timeout=15,
    )
    response.raise_for_status()
    return response.json()

def main():
    api_key = os.getenv("OPENWEATHER_API_KEY")
    if not api_key:
        print("Missing API key.")
        print("Set the OPENWEATHER_API_KEY environment variable and run again.")
        return
    city = input("Enter city name (e.g. Hyderabad): ").strip()
    if not city:
        print("City name cannot be empty.")
        return
    try:
        data = get_weather(city, api_key)
        weather = data["weather"][0]
        print(f"\nWeather in {data['name']}, {data['sys']['country']}")
        print(f"Condition: {weather['description'].title()}")
        print(f"Temperature: {data['main']['temp']:.1f} °C")
        print(f"Feels like: {data['main']['feels_like']:.1f} °C")
        print(f"Humidity: {data['main']['humidity']}%")
        print(f"Wind speed: {data['wind']['speed']} m/s")
    except requests.HTTPError as exc:
        if exc.response is not None and exc.response.status_code == 401:
            print("The API key is invalid or not active yet.")
        elif exc.response is not None and exc.response.status_code == 404:
            print("City not found. Check the spelling.")
        else:
            print(f"Weather service error: {exc}")
    except requests.RequestException as exc:
        print(f"Network error: {exc}")
    except (KeyError, IndexError, TypeError):
        print("The weather service returned an unexpected response.")

if __name__ == "__main__":
    main()
