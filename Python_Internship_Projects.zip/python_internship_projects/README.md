# Python Programming Internship Projects

This repository contains five beginner-level Python projects corresponding to the five tasks shown in the internship portal.

## Projects
1. Interactive Calculator & Unit Converter
2. Number Guessing Game & Word Counter
3. Personal Expense Tracker with CSV
4. Web Scraper for Headlines & Quotes
5. Weather App with Live OpenWeatherMap API

Each project has its own folder and README with setup/run instructions. Projects 1–3 use only the Python standard library. Projects 4–5 require packages listed in their `requirements.txt`. Project 5 also requires your own OpenWeatherMap API key.

## Before submitting
- Run each project yourself and test its features.
- Add screenshots of successful runs to each project folder if your internship portal allows them.
- Do not upload API keys, passwords, or personal data.
- Read and follow your internship provider's project requirements and submission rules.
- Make sure you understand the code and can explain it during review.
